package com.example.simple_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.*;


public class MainActivity extends AppCompatActivity {

    Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9,
            buttonAdd, buttonSub, buttonDivision, buttonMul, buttonPoint, buttonClear, buttonEqual,
            button00, buttonHelp, buttonDelete, buttonHistory;
    TextView edttxt;
    LinkedList<String> history;
    boolean helpActivated, hisActivated;
    String tmpStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        history = new LinkedList<String>();

        helpActivated = false;
        hisActivated = false;

        button0 = (Button) findViewById(R.id.btn0);
        button1 = (Button) findViewById(R.id.btn1);
        button2 = (Button) findViewById(R.id.btn2);
        button3 = (Button) findViewById(R.id.btn3);
        button4 = (Button) findViewById(R.id.btn4);
        button5 = (Button) findViewById(R.id.btn5);
        button6 = (Button) findViewById(R.id.btn6);
        button7 = (Button) findViewById(R.id.btn7);
        button8 = (Button) findViewById(R.id.btn8);
        button9 = (Button) findViewById(R.id.btn9);
        buttonAdd = (Button) findViewById(R.id.btnPlus);
        buttonSub = (Button) findViewById(R.id.btnMinus);
        buttonDivision = (Button) findViewById(R.id.btnDivide);
        buttonMul = (Button) findViewById(R.id.btnMultiply);
        buttonPoint = (Button) findViewById(R.id.btnPoint);
        buttonClear = (Button) findViewById(R.id.btnClear);
        buttonEqual = (Button) findViewById(R.id.btnEqual);
        button00 = (Button) findViewById(R.id.btn00);
        buttonHelp = (Button) findViewById(R.id.btnHelp);
        buttonDelete = (Button) findViewById(R.id.btnDelete);
        buttonHistory = (Button) findViewById(R.id.btnHistory);
        edttxt = (TextView) findViewById(R.id.screen);
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "0");}
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "1");}
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "2");}
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "3");}
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "4");}
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "5");}
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "6");}
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "7");}
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "8");}
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "9");}
            }
        });
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edttxt.getText().toString();
                if (! helpActivated && ! hisActivated && text.length() > 0 && ! (text.length()==1 && text.equals("-"))) {
                    if (text.substring(text.length()-1).equals(".")) {text=text.substring(0,text.length()-1);}
                    if (text.substring(text.length()-1).equals("+") || text.substring(text.length()-1).equals("-") || text.substring(text.length()-1).equals("*") || text.substring(text.length()-1).equals("/")) {
                        edttxt.setText(text.substring(0,text.length()-1) + "+");
                    } else {
                        edttxt.setText(text + "+");
                    }
                }
            }
        });
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edttxt.getText().toString();
                if (! helpActivated && ! hisActivated) {
                    if (text.length() == 0) {
                        edttxt.setText(text + "-");
                    } else if (text.substring(text.length()-1).equals(".")) {
                            edttxt.setText(text=text.substring(0,text.length()-1)+"-");
                    } else if (text.substring(text.length()-1).equals("+") || text.substring(text.length()-1).equals("-") || text.substring(text.length()-1).equals("*") || text.substring(text.length()-1).equals("/")) {
                            edttxt.setText(text.substring(0,text.length()-1) + "-");
                    } else {
                            edttxt.setText(text + "-");
                    }
                }
            }
        });
        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edttxt.getText().toString();
                if (! helpActivated && ! hisActivated && text.length() > 0 && ! (text.length()==1 && text.equals("-"))) {
                    if (text.substring(text.length()-1).equals(".")) {text=text.substring(0,text.length()-1);}
                    if (text.substring(text.length()-1).equals("+") || text.substring(text.length()-1).equals("-") || text.substring(text.length()-1).equals("*") || text.substring(text.length()-1).equals("/")) {
                        edttxt.setText(text.substring(0,text.length()-1) + "*");
                    } else {
                        edttxt.setText(text + "*");
                    }
                }
            }
        });
        buttonDivision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edttxt.getText().toString();
                if (! helpActivated && ! hisActivated && text.length() > 0 && ! (text.length()==1 && text.equals("-"))) {
                    if (text.substring(text.length()-1).equals(".")) {text=text.substring(0,text.length()-1);}
                    if (text.substring(text.length()-1).equals("+") || text.substring(text.length()-1).equals("-") || text.substring(text.length()-1).equals("*") || text.substring(text.length()-1).equals("/")) {
                        edttxt.setText(text.substring(0,text.length()-1) + "/");
                    } else {
                        edttxt.setText(text + "/");
                    }
                }
            }
        });
        buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edttxt.getText().toString();
                if (! helpActivated && ! hisActivated && text.length() > 0 && ! (text.length()==1 && text.equals("-"))) {
                    if (text.substring(text.length()-1).equals(".") || text.substring(text.length()-1).equals("+") || text.substring(text.length()-1).equals("-") || text.substring(text.length()-1).equals("*") || text.substring(text.length()-1).equals("/")) {text=text.substring(0,text.length()-1);}
                    boolean firstOperandIsNegative = text.substring(0,1).equals("-");
                    if (firstOperandIsNegative) {text=text.substring(1);}
                    float val1, val2;
                    String[] operands = text.trim().split("\\+|-|\\*|/");
                    LinkedList<String> operators = new LinkedList<String>();
                    for (int i=0; i<text.length(); i++) {
                        if (text.charAt(i)=='+' || text.charAt(i)=='-' || text.charAt(i)=='*' || text.charAt(i)=='/') {operators.addLast(text.substring(i,i+1));}
                    }
                    Stack<String> operatorStack = new Stack<String>();
                    LinkedList<String> postfixExpression = new LinkedList<String>();
                    if (operands.length == 1) {
                        String thisOperand = operands[0];
                        int k = 0;
                        while (k<thisOperand.length() && thisOperand.charAt(k)=='0'){
                            k++;
                        }
                        if (k==thisOperand.length()) {
                            postfixExpression.addLast(thisOperand.substring(k-1));
                        } else if (k>0 && thisOperand.charAt(k)=='.') {
                            postfixExpression.addLast(thisOperand.substring(k-1));
                        } else if (k>0) {
                            postfixExpression.addLast(thisOperand.substring(k));
                        } else {
                            postfixExpression.addLast(thisOperand);
                        }
                    } else {
                        int i=0;
                        while(operators.size()!=0) {
                            postfixExpression.addLast(operands[i++]);
                            String operator = operators.remove();
                            if (operatorStack.isEmpty()) {
                                operatorStack.push(operator);
                            } else if ((operatorStack.peek().equals("+") || operatorStack.peek().equals("-")) && (operator.equals("*") || operator.equals("/"))) {
                                operatorStack.push(operator);
                            } else {
                                if (operator.equals("*") || operator.equals("/")) {
                                    while (! operatorStack.isEmpty() && (! operatorStack.peek().equals("+") && ! operatorStack.peek().equals("-"))) {
                                        postfixExpression.addLast(operatorStack.pop());
                                    }
                                } else if (operator.equals("+") || operator.equals("-")) {
                                    while (! operatorStack.isEmpty()) {
                                        postfixExpression.addLast(operatorStack.pop());
                                    }
                                }
                                operatorStack.push(operator);
                            }
                        }
                        postfixExpression.addLast(operands[i]);
                        while(operatorStack.size()!=0) {postfixExpression.addLast(operatorStack.pop());}
                    }
                    Stack<String> operandStack = new Stack<String>();
                    for (int i=0; i<postfixExpression.size(); i++) {
                        if (! postfixExpression.get(i).equals("+") && ! postfixExpression.get(i).equals("-") && ! postfixExpression.get(i).equals("*") && ! postfixExpression.get(i).equals("/")) {
                            operandStack.push(postfixExpression.get(i));
                        } else {
                            val2 = Float.parseFloat(operandStack.pop());
                            val1 = Float.parseFloat(operandStack.pop());
                            if (firstOperandIsNegative) {
                                if (postfixExpression.get(i).equals("+")) {
                                    operandStack.push(String.valueOf(val1-val2));
                                } else if (postfixExpression.get(i).equals("-")) {
                                    operandStack.push(String.valueOf(val1+val2));
                                } else if (postfixExpression.get(i).equals("*")) {
                                    operandStack.push(String.valueOf(val1*val2));
                                } else if (postfixExpression.get(i).equals("/")) {
                                    operandStack.push(String.valueOf(val1/val2));
                                }
                            } else {
                                if (postfixExpression.get(i).equals("+")) {
                                    operandStack.push(String.valueOf(val1+val2));
                                } else if (postfixExpression.get(i).equals("-")) {
                                    operandStack.push(String.valueOf(val1-val2));
                                } else if (postfixExpression.get(i).equals("*")) {
                                    operandStack.push(String.valueOf(val1*val2));
                                } else if (postfixExpression.get(i).equals("/")) {
                                    operandStack.push(String.valueOf(val1/val2));
                                }
                            }
                        }
                    }
                    String val = operandStack.pop();
                    if (firstOperandIsNegative) {
                        val=""+((-1)*Float.parseFloat(val));
                        text="-"+text;
                    }
                    edttxt.setText(val);
                    text = text+" = "+val;
                    history.addLast(text);
                }
            }
        });
        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hisActivated) {
                    history.clear();
                }
                edttxt.setText("");
                helpActivated = false;
                hisActivated = false;
            }
        });
        buttonPoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {
                    String text = edttxt.getText().toString();
                    if (text.length() == 0 || text.charAt(text.length()-1)=='+' || text.charAt(text.length()-1)=='-' || text.charAt(text.length()-1)=='*' || text.charAt(text.length()-1)=='/') {
                        edttxt.setText(edttxt.getText() + "0.");
                    } else if (text.charAt(text.length()-1)!='.') {
                        int i=text.length()-1;
                        while (i>=0) {
                            if (text.charAt(i)=='+' || text.charAt(i)=='-' || text.charAt(i)=='*' || text.charAt(i)=='/') {break;}
                            i--;
                        }
                        i++;
                        if (! text.substring(i).contains(".")) {
                            edttxt.setText(edttxt.getText() + ".");
                        }
                    }
                }
            }
        });
        button00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated) {edttxt.setText(edttxt.getText() + "00");}
            }
        });
        buttonHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (helpActivated) {
                    edttxt.setText(tmpStorage);
                    helpActivated = false;
                } else {
                    if (! hisActivated) {
                        tmpStorage = edttxt.getText().toString();
                    }
                    edttxt.setText("Simple calculator: version 1.0 (click ? button to return)");
                    helpActivated = true;
                    hisActivated = false;
                }
            }
        });
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! helpActivated && ! hisActivated && edttxt.getText().toString().length() > 0) {
                    String text = edttxt.getText().toString();
                    edttxt.setText(text.substring(0,text.length()-1));
                }
            }
        });
        buttonHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hisActivated) {
                    edttxt.setText(tmpStorage);
                    hisActivated = false;
                } else {
                    if (! helpActivated) {
                        tmpStorage = edttxt.getText().toString();
                    }
                    String display = new String();
                    for (String ele: history) {
                        display = ele + System.getProperty("line.separator") + display;
                    }
                    display = "(click C to delete all records, click HIS button to return)" + System.getProperty("line.separator") +display;
                    edttxt.setText(display);
                    hisActivated = true;
                    helpActivated = false;
                }
            }
        });
    }
}